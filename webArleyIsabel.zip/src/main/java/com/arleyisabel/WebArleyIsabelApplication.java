package com.arleyisabel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebArleyIsabelApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebArleyIsabelApplication.class, args);
	}

}
